// pages/dashboard/siswa/[id]/rekomendasi.js

import { useState, useEffect } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../../../../utils/supabaseClient';
import Layout from '../../../../components/Layout';
import toast from 'react-hot-toast';
import Spinner from '../../../../components/Spinner';

export default function RekomendasiPage() {
  const router = useRouter();
  const { id } = router.query;
  const [siswa, setSiswa] = useState(null);
  const [lastObs, setLastObs] = useState('');
  const [rekom, setRekom] = useState([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!id) return;
    (async () => {
      const { data: s } = await supabase.from('siswa').select('nama, kelas').eq('id', id).single();
      setSiswa(s);
      const { data: obs } = await supabase
        .from('observasi')
        .select('catatan')
        .eq('siswa_id', id)
        .order('created_at', { ascending: false })
        .limit(1);
      setLastObs(obs?.[0]?.catatan || '');
    })();
  }, [id]);

  const handleGenerate = async () => {
    if (!lastObs) return toast.error('Belum ada observasi.');
    setLoading(true);
    const tId = toast.loading('Menghasilkan rekomendasi...');
    try {
      const res = await fetch('/api/rekomendasi', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ character: lastObs }),
      });
      const { rekomendasi, error } = await res.json();
      if (error) throw new Error(error);
      setRekom(rekomendasi);
      toast.success('Rekomendasi siap!', { id: tId });
    } catch (err) {
      toast.error('Error: ' + err.message, { id: tId });
    } finally {
      setLoading(false);
    }
  };

  if (!siswa) return null;
  return (
    <Layout>
      <div className="p-6 max-w-lg mx-auto space-y-6">
        <h1 className="text-2xl font-bold">Rekomendasi Pembelajaran</h1>
        <p><strong>{siswa.nama}</strong> — Kelas {siswa.kelas}</p>
        <p><em>Observasi Terakhir:</em> {lastObs || 'Belum ada observasi'}</p>
        <button
          onClick={handleGenerate}
          disabled={loading || !lastObs}
          className={`px-4 py-2 rounded text-white ${
            loading ? 'bg-gray-400' : 'bg-indigo-600 hover:bg-indigo-700'
          }`}
        >
          {loading ? <Spinner size={20} /> : 'Generate Rekomendasi'}
        </button>
        {rekom.length > 0 && (
          <div className="bg-white p-4 rounded shadow">
            <h2 className="text-xl font-semibold mb-2">Hasil Rekomendasi:</h2>
            <ol className="list-decimal pl-6 space-y-1">
              {rekom.map((step, i) => <li key={i}>{step}</li>)}
            </ol>
          </div>
        )}
      </div>
    </Layout>
  );
}
