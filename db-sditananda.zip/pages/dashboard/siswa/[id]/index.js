import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../../../../utils/supabaseClient';
import Layout from '../../../../components/Layout';
import Link from 'next/link';
import toast from 'react-hot-toast';
import Spinner from '../../../../components/Spinner';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

export default function ProfilSiswa() {
  const router = useRouter();
  const { id } = router.query;

  const [siswa, setSiswa] = useState(null);
  const [obs, setObs] = useState([]);
  const [tfidfResult, setTfidfResult] = useState(null);
  const [embedResult, setEmbedResult] = useState(null);
  const [hasilAnalisis, setHasilAnalisis] = useState(null);
  const [exportingPDF, setExportingPDF] = useState(false);
  const [exportingExcel, setExportingExcel] = useState(false);

  useEffect(() => {
    if (!id) return;
    (async () => {
      const { data: sessionData } = await supabase.auth.getSession();
      if (!sessionData.session) return router.replace('/login');

      const { data: siswaData } = await supabase
        .from('siswa')
        .select('nama, nisn, kelas')
        .eq('id', id)
        .single();
      setSiswa(siswaData);

      const { data: obsData } = await supabase
        .from('observasi')
        .select('catatan, karakter, created_at')
        .eq('siswa_id', id)
        .order('created_at', { ascending: true });
      setObs(obsData || []);

      const { data: hasilData } = await supabase
        .from('hasil_observasi')
        .select('hasil_analisis, created_at')
        .eq('siswa_id', id)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();
      setHasilAnalisis(hasilData);
    })();
  }, [id, router]);

  if (!siswa) return null;

  const excelData = obs.map((o) => ({
    Tanggal: new Date(o.created_at).toLocaleDateString(),
    Catatan: o.catatan,
    Karakter: o.karakter || '-',
  }));

  const exportPDF = async () => {
    setExportingPDF(true);
    const tId = toast.loading('Membuat PDF...');
    const doc = new jsPDF('p', 'mm', 'a4');
    const element = document.getElementById('report-container');
    const canvas = await html2canvas(element, { scale: 2 });
    const imgData = canvas.toDataURL('image/png');
    const pdfWidth = doc.internal.pageSize.getWidth() - 20;
    const pdfHeight = (canvas.height * pdfWidth) / canvas.width;
    doc.addImage(imgData, 'PNG', 10, 10, pdfWidth, pdfHeight);
    doc.save(`${siswa.nama}_Laporan_Observasi.pdf`);
    toast.success('PDF siap diunduh!', { id: tId });
    setExportingPDF(false);
  };

  const exportExcel = () => {
    setExportingExcel(true);
    const tId = toast.loading('Membuat Excel...');
    const ws = XLSX.utils.json_to_sheet(excelData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Observasi');
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
    saveAs(new Blob([wbout], { type: 'application/octet-stream' }),
      `${siswa.nama}_Observasi.xlsx`);
    toast.success('Excel siap diunduh!', { id: tId });
    setExportingExcel(false);
  };

  const analyzeTfidf = async () => {
    const lastText = obs[obs.length - 1]?.catatan;
    if (!lastText) return toast.error('Belum ada observasi untuk dianalisis');
    const tId = toast.loading('Memproses TF-IDF...');
    try {
      const res = await fetch('/api/analyze/tfidf', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: lastText }),
      });
      const { vector } = await res.json();
      setTfidfResult(vector);
      toast.success('TF-IDF selesai', { id: tId });
    } catch (err) {
      toast.error('Gagal TF-IDF: ' + err.message, { id: tId });
    }
  };

  const analyzeEmbedding = async () => {
    const lastText = obs[obs.length - 1]?.catatan;
    if (!lastText) return toast.error('Belum ada observasi untuk dianalisis');
    const tId = toast.loading('Memproses Embedding...');
    try {
      const res = await fetch('/api/analyze/embedding', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: lastText }),
      });
      const { embedding } = await res.json();
      setEmbedResult(embedding);
      toast.success('Embedding selesai', { id: tId });
    } catch (err) {
      toast.error('Gagal Embedding: ' + err.message, { id: tId });
    }
  };

  return (
    <Layout>
      <div id="report-container" className="p-6 max-w-3xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-2xl font-bold">{siswa.nama}</h1>
            <p className="text-sm text-gray-600">
              NISN: <span className="font-mono">{siswa.nisn || '-'}</span>
            </p>
            <p className="text-sm text-gray-600">Kelas: {siswa.kelas}</p>
          </div>
          <div className="flex gap-2">
            <Link
              href={`/dashboard/siswa/edit/${id}`}
              className="bg-yellow-500 text-white px-3 py-1 rounded hover:bg-yellow-600"
            >
              ✏️ Edit Siswa
            </Link>
            <Link
              href={`/dashboard/siswa/${id}/observasi`}
              className="bg-blue-600 text-white px-3 py-1 rounded hover:bg-blue-700"
            >
              ➕ Tambah Observasi
            </Link>
          </div>
        </div>

        {/* Hasil Analisis AI */}
        {hasilAnalisis && (
          <div className="p-4 bg-yellow-50 border border-yellow-300 rounded-lg">
            <h2 className="text-xl font-semibold text-yellow-800 mb-2">🧠 Hasil Analisis AI</h2>
            <pre className="whitespace-pre-wrap text-gray-800 text-sm">{hasilAnalisis.hasil_analisis}</pre>
            <p className="text-xs text-right text-gray-500 mt-2">
              Diperbarui: {new Date(hasilAnalisis.created_at).toLocaleString()}
            </p>
          </div>
        )}

        {/* Riwayat Observasi */}
        <div>
          <h2 className="text-xl font-semibold mb-2">Riwayat Observasi</h2>
          {obs.length === 0 ? (
            <p className="text-gray-500">Belum ada observasi.</p>
          ) : (
            <ul className="list-disc pl-6 space-y-1">
              {obs.map((o, i) => (
                <li key={i}>
                  <span className="font-medium">
                    {new Date(o.created_at).toLocaleDateString()}
                  </span>{' '}
                  — {o.catatan}
                  <span className="ml-2 px-2 py-1 text-xs bg-blue-100 text-blue-800 rounded">
                    {o.karakter || '-'}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Tombol Export dan AI */}
        <div className="flex flex-wrap gap-2">
          <button
            onClick={exportPDF}
            disabled={exportingPDF}
            className="bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 disabled:opacity-50"
          >
            {exportingPDF ? <Spinner size={16} /> : '📄 Unduh PDF'}
          </button>
          <button
            onClick={exportExcel}
            disabled={exportingExcel}
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:opacity-50"
          >
            {exportingExcel ? <Spinner size={16} /> : '📊 Unduh Excel'}
          </button>
          <button
            onClick={analyzeTfidf}
            className="bg-indigo-600 text-white px-4 py-2 rounded hover:bg-indigo-700"
          >
            🔎 Analisis TF-IDF
          </button>
          <button
            onClick={analyzeEmbedding}
            className="bg-indigo-800 text-white px-4 py-2 rounded hover:bg-indigo-900"
          >
            🤖 Analisis Embedding
          </button>
        </div>

        {/* Hasil Analisis Manual */}
        {tfidfResult && (
          <pre className="bg-gray-100 p-4 rounded overflow-auto">
            {JSON.stringify(tfidfResult, null, 2)}
          </pre>
        )}
        {embedResult && (
          <div className="bg-gray-100 p-4 rounded">
            <strong>Embedding length:</strong> {embedResult.length}
          </div>
        )}
      </div>
    </Layout>
  );
}
