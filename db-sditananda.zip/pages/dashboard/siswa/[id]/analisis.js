import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../../../../utils/supabaseClient';
import Layout from '../../../../components/Layout';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

export default function AnalisisKarakterSiswa() {
  const router = useRouter();
  const { id: siswaId } = router.query;

  const [siswa, setSiswa] = useState(null);
  const [analisis, setAnalisis] = useState(null);
  const [histori, setHistori] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!siswaId) return;

    const fetchData = async () => {
      // Ambil data siswa
      const { data: siswaData, error: err1 } = await supabase
        .from('siswa')
        .select('*')
        .eq('id', siswaId)
        .single();

      if (err1) {
        console.error('❌ Gagal ambil data siswa:', err1.message);
        return;
      }

      // Ambil hasil analisis terakhir
      const { data: hasil, error: err2 } = await supabase
        .from('hasil_analisis')
        .select('*')
        .eq('siswa_id', siswaId)
        .order('created_at', { ascending: false })
        .limit(1)
        .single();

      // Ambil semua observasi siswa
      const { data: observasiList, error: err3 } = await supabase
        .from('jawaban_observasi')
        .select('waktu_observasi, jawaban')
        .eq('siswa_id', siswaId);

      if (err3) {
        console.error('❌ Gagal ambil histori observasi:', err3.message);
      } else {
        const grouped = {};
        observasiList.forEach((item) => {
          const waktu = item.waktu_observasi;
          if (!grouped[waktu]) grouped[waktu] = [];
          grouped[waktu].push(item.jawaban);
        });

        const grafik = Object.entries(grouped).map(([waktu, jawabanList]) => {
          const nilai = jawabanList.map((j) => {
            const n = parseFloat(j);
            if (!isNaN(n)) return n;
            if (j === 'Ya') return 1;
            if (j === 'Tidak') return 0;
            return 0;
          });
          const rata2 = nilai.reduce((a, b) => a + b, 0) / nilai.length;
          return {
            tanggal: new Date(waktu).toLocaleDateString(),
            nilai: parseFloat(rata2.toFixed(2)),
          };
        });

        setHistori(grafik);
      }

      setSiswa(siswaData);
      setAnalisis(hasil);
      setLoading(false);
    };

    fetchData();
  }, [siswaId]);

  const handleExportPDF = async () => {
    const element = document.getElementById('analisis-box');
    if (!element) return;

    const canvas = await html2canvas(element);
    const imgData = canvas.toDataURL('image/png');

    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const width = pdf.internal.pageSize.getWidth();
    const height = (canvas.height * width) / canvas.width;

    pdf.addImage(imgData, 'PNG', 0, 10, width, height);
    pdf.save(`Analisis_${siswa?.nama || siswaId}.pdf`);
  };

  if (loading) return <p className="p-6">🔄 Memuat analisis siswa…</p>;

  return (
    <Layout>
      <div className="p-6 max-w-4xl mx-auto">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Analisis Karakter Siswa</h1>
          <p className="text-gray-600">Berdasarkan observasi terbaru oleh guru</p>
        </div>

        {/* Data Siswa */}
        <div className="bg-gray-100 p-4 rounded-lg mb-6">
          <p><strong>Nama:</strong> {siswa.nama}</p>
          <p><strong>Kelas:</strong> {siswa.kelas}</p>
        </div>

        {/* Hasil Analisis */}
        {analisis ? (
          <div id="analisis-box" className="bg-white border p-6 rounded-lg shadow whitespace-pre-line">
            <p className="text-gray-500 text-sm mb-2">🕒 {new Date(analisis.created_at).toLocaleString()}</p>
            <h2 className="text-lg font-bold mb-3">Hasil Analisis AI</h2>
            <p>{analisis.isi_analisis}</p>
          </div>
        ) : (
          <p className="text-red-500">Belum ada hasil analisis AI.</p>
        )}

        {/* Grafik Line */}
        {histori.length > 0 && (
          <div className="my-8">
            <h2 className="text-lg font-bold mb-3">Grafik Perkembangan Observasi</h2>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={histori}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="tanggal" />
                <YAxis domain={[0, 5]} />
                <Tooltip />
                <Line type="monotone" dataKey="nilai" stroke="#2563eb" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Tombol Aksi */}
        <div className="mt-6 flex flex-wrap gap-4">
          <button
            onClick={() => router.push('/dashboard/siswa/' + siswaId)}
            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded"
          >
            Kembali ke Profil Siswa
          </button>
          <button
            onClick={handleExportPDF}
            className="bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded"
          >
            Export PDF
          </button>
        </div>
      </div>
    </Layout>
  );
}
