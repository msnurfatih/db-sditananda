// pages/dashboard/siswa/[id]/observasi.js

import { useEffect, useState } from 'react'
import { useRouter } from 'next/router'
import Layout from '../../../../components/Layout'
import supabase from '../../../../utils/supabaseClient'

export default function ObservasiPerSiswa() {
  const router = useRouter()
  const { id } = router.query

  const [siswa, setSiswa] = useState(null)
  const [observasi, setObservasi] = useState('')
  const [hasil, setHasil] = useState('')
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    if (!id) return
    const fetchData = async () => {
      const { data, error } = await supabase.from('siswa').select('*').eq('id', id).single()
      if (!error) setSiswa(data)
    }
    fetchData()
  }, [id])

  const handleSubmit = async () => {
    if (!observasi.trim()) return alert('Observasi tidak boleh kosong!')
    setLoading(true)

    const res = await fetch('/api/generate-rekomendasi', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ teks: observasi })
    })

    const { rekomendasi } = await res.json()
    setHasil(rekomendasi)

    await supabase.from('observasi').insert({
      siswa_id: id,
      teks: observasi,
      hasil: rekomendasi
    })

    setLoading(false)
    alert('✅ Disimpan dan dianalisis!')
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        <h1 className="text-2xl font-bold">📝 Observasi Siswa</h1>

        {siswa && (
          <div className="bg-gray-100 p-4 rounded">
            <p><strong>Nama:</strong> {siswa.nama}</p>
            <p><strong>Kelas:</strong> {siswa.kelas}</p>
          </div>
        )}

        <div>
          <label className="block font-semibold mb-1">Teks Observasi</label>
          <textarea
            value={observasi}
            onChange={(e) => setObservasi(e.target.value)}
            placeholder="Tulis hasil pengamatan guru di sini..."
            rows={5}
            className="w-full border p-2 rounded"
          />
        </div>

        <button
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          onClick={handleSubmit}
          disabled={loading}
        >
          {loading ? 'Menganalisis...' : '💡 Analisis & Simpan'}
        </button>

        {hasil && (
          <div className="bg-green-100 p-4 rounded border mt-4">
            <h2 className="font-semibold">Rekomendasi AI:</h2>
            <p>{hasil}</p>
          </div>
        )}
      </div>
    </Layout>
  )
}
