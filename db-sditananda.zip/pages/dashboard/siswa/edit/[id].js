import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../../../../utils/supabaseClient';
import Layout from '../../../../components/Layout';
import Spinner from '../../../../components/Spinner';
import toast from 'react-hot-toast';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip as LineTip,
  BarChart, Bar, Tooltip as BarTip, ResponsiveContainer
} from 'recharts';

export default function EditDanGrafikSiswa() {
  const router = useRouter();
  const { id } = router.query;

  const [siswa, setSiswa] = useState(null);
  const [obs, setObs] = useState([]);
  const [loading, setLoading] = useState(true);

  // State form
  const [form, setForm] = useState({
    nama: '', kelas: '', jenis_kelamin: '', tempat_lahir: '',
    tanggal_lahir: '', alamat: '', ayah_nama: '', ayah_pekerjaan: '',
    ibu_nama: '', ibu_pekerjaan: '', nisn: ''
  });

  useEffect(() => {
    if (!id) return;
    const fetchData = async () => {
      const { data: siswaData } = await supabase.from('siswa').select('*').eq('id', id).single();
      const { data: obsData } = await supabase.from('observasi')
        .select('catatan, karakter, created_at').eq('siswa_id', id).order('created_at', { ascending: true });
      setSiswa(siswaData);
      setForm(siswaData);
      setObs(obsData || []);
      setLoading(false);
    };
    fetchData();
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleUpdate = async () => {
    const { error } = await supabase.from('siswa').update(form).eq('id', id);
    if (error) {
      toast.error('❌ Gagal update');
    } else {
      toast.success('✅ Data siswa diperbarui');
    }
  };

  // Chart Data
  const freq = {};
  obs.forEach((o) => {
    const key = o.catatan.split(' ')[0] || '(kosong)';
    freq[key] = (freq[key] || 0) + 1;
  });
  const barData = Object.entries(freq).map(([karakter, jumlah]) => ({ karakter, jumlah }));

  const byDate = {};
  obs.forEach((o) => {
    const date = new Date(o.created_at).toISOString().split('T')[0];
    byDate[date] = (byDate[date] || 0) + 1;
  });
  const lineData = Object.entries(byDate)
    .map(([date, count]) => ({ date, count }))
    .sort((a, b) => a.date.localeCompare(b.date));

  if (loading) return <Spinner />;

  return (
    <Layout pageTitle={`🧠 Edit & Grafik Siswa: ${form.nama}`}>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 p-4">
        {/* Form Edit */}
        <div className="space-y-4">
          <h2 className="text-xl font-bold">Form Edit Siswa</h2>
          <input name="nisn" value={form.nisn || ''} onChange={handleChange} placeholder="NISN" className="border p-2 rounded w-full" />
          <input name="nama" value={form.nama} onChange={handleChange} placeholder="Nama Lengkap" className="border p-2 rounded w-full" />
          <input name="kelas" value={form.kelas} onChange={handleChange} placeholder="Kelas" className="border p-2 rounded w-full" />
          <input name="jenis_kelamin" value={form.jenis_kelamin} onChange={handleChange} placeholder="Jenis Kelamin" className="border p-2 rounded w-full" />
          <input name="tempat_lahir" value={form.tempat_lahir} onChange={handleChange} placeholder="Tempat Lahir" className="border p-2 rounded w-full" />
          <input name="tanggal_lahir" type="date" value={form.tanggal_lahir} onChange={handleChange} className="border p-2 rounded w-full" />
          <input name="alamat" value={form.alamat} onChange={handleChange} placeholder="Alamat" className="border p-2 rounded w-full" />
          <input name="ayah_nama" value={form.ayah_nama} onChange={handleChange} placeholder="Nama Ayah" className="border p-2 rounded w-full" />
          <input name="ayah_pekerjaan" value={form.ayah_pekerjaan} onChange={handleChange} placeholder="Pekerjaan Ayah" className="border p-2 rounded w-full" />
          <input name="ibu_nama" value={form.ibu_nama} onChange={handleChange} placeholder="Nama Ibu" className="border p-2 rounded w-full" />
          <input name="ibu_pekerjaan" value={form.ibu_pekerjaan} onChange={handleChange} placeholder="Pekerjaan Ibu" className="border p-2 rounded w-full" />
          <button onClick={handleUpdate} className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
            ✅ Simpan Perubahan
          </button>
        </div>

        {/* Grafik */}
        <div>
          <h2 className="text-xl font-bold mb-4">📊 Grafik Observasi</h2>

          <div className="mb-8">
            <h3 className="text-md font-semibold">Karakter Teramati</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={barData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="karakter" />
                <YAxis />
                <Bar dataKey="jumlah" fill="#3182ce" />
                <BarTip />
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div>
            <h3 className="text-md font-semibold">Frekuensi Observasi</h3>
            <ResponsiveContainer width="100%" height={200}>
              <LineChart data={lineData}>
                <XAxis dataKey="date" />
                <YAxis />
                <CartesianGrid strokeDasharray="3 3" />
                <Line type="monotone" dataKey="count" stroke="#4c51bf" />
                <LineTip />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>
    </Layout>
  );
}
