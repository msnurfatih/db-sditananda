// Next.js configuration
module.exports = {};
