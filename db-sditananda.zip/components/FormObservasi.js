export default function FormObservasi() { return <div>FormObservasi</div>; }
