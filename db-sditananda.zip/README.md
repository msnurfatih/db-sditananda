# Sistem Karakter AI

Documentasi proyek.
